const SupervisorsList=[
    {
      key:1,
      name:"Dr Shahzad Sarwar (Professor)",
      details:"• PhD Electrical Engineering and IT, Vienna University of Technology Austria, 2008, MS Computer Science, LUMS Lahore, 2004, B.Sc Civil Engineering, UET Taxila, 1998",
      email:"•  Principal@pucit.edu.pk, S.sarwar@pucit.edu.pk"
    },
  
    {
      key:2,
      name:"Abdul Mateen (Assistant Professor)",
      details:"• PhD Computer Science (in progress), PU MS Computer Science, UMT M.Sc Computer Science, PU, 2003 Research / Teaching Interests: Programming, Data Structures",
      email:"• amateen@pucit.edu.pk"
    },
    {
      key:3,
      name:"Umair Babar (Assistant Professor)",
      details:"• PhD Computer Science (course work completed) PUCIT, University of the Punjab, Lahore MS Computer Science, UCP Lahore, 2008 BS Hons. Computer Science, UCP Lahore, 2005 Research / Teaching Interests:Object Oriented System Design and Implementation, Data Structures and Algorithms, Theory of Automata",
      email:"• umair.babar@pucit.edu.pk"
    },
    {
      key:4,
      name:"Dr Muhammad Murtaza Yousaf (Professor)",
      details:"• PhD Computer Science, University of Innsbruck, Austria, 2008, M.Sc Computer Science, PU, 2001 (Gold Medal)",
      email:"• murtaza@pucit.edu.pk"
    },
    {
      key:5,
      name:"Dr Waqar ul Qunain (Professor)",
      details:"• PhD Computer Science (Vrije University, Amsterdam, The Netherlands),M.Sc Computer Science (University of The Punjab, Pakistan), PGD Computer Science (University of The Punjab, Pakistan)",
      email:"•  swjaffry@pucit.edu.pk, chairman.dit@pucit.edu.pk, chairman.dit@pu.edu.pk"
    },
    {
      key:6,
      name:"Dr Shahid Manzoor (Associate Professor)",
      details:"• PhD in Bioinformatics, Swedish University of Agricultural Science, Uppsala, Sweden,MS in Bioinformatics, Swedish University of Agricultural Science, Uppsala, Sweden,M.Sc in Computer Science, University of Agriculture, Faisalabad, Pakistan,B.Sc (Hons), University of Agriculture, Faisalabad, Pakistan",
      email:"• chairman.dds@pucit.edu.pk, chairman.dds@pu.edu.pk"
    },
    {
      key:5,
      name:"Dr Waqar ul Qunain (Professor)",
      details:"• PhD Computer Science (Vrije University, Amsterdam, The Netherlands),M.Sc Computer Science (University of The Punjab, Pakistan), PGD Computer Science (University of The Punjab, Pakistan)",
      email:"•  swjaffry@pucit.edu.pk, chairman.dit@pucit.edu.pk, chairman.dit@pu.edu.pk"
    },
    {
      key:5,
      name:"Dr Waqar ul Qunain (Professor)",
      details:"• PhD Computer Science (Vrije University, Amsterdam, The Netherlands),M.Sc Computer Science (University of The Punjab, Pakistan), PGD Computer Science (University of The Punjab, Pakistan)",
      email:"•  swjaffry@pucit.edu.pk, chairman.dit@pucit.edu.pk, chairman.dit@pu.edu.pk"
    },
    {
      key:5,
      name:"Dr Waqar ul Qunain (Professor)",
      details:"• PhD Computer Science (Vrije University, Amsterdam, The Netherlands),M.Sc Computer Science (University of The Punjab, Pakistan), PGD Computer Science (University of The Punjab, Pakistan)",
      email:"•  swjaffry@pucit.edu.pk, chairman.dit@pucit.edu.pk, chairman.dit@pu.edu.pk"
    }
  ];
  export default SupervisorsList;
  