const RequestsList=[
    {
      key:1,
      title:"Request For FYP",
      sender:"Hamda Tariq",
      email: "bcsf18m525@pucit.edu.pk",
      detail:"I want to have FYP enrolled with you in web development. Kindly allow me to do so!"
    },
  
    {
      key:2,
      title:"Request for Enrollement",
      sender:"Laraib",
      email:"bcsf18m523@pucit.edu.pk",
     detail:"I want to enroll FYP with you in AI. Kindly allow me to do so!"
    },

    {
        key:3,
        title:"E-Commerce Website",
        sender:"Abeera Khalid",
        email:"bcsf18m526@pucit.edu.pk",
        detail:"It is stated that I want to have my FYP with you.Kindly allow me to do so!"
      },
      {
        key:4,
        title:"FYP Request",
        sender:"Sidra Tanveer",
        email:"bcsf18m541@pucit.edu.pk",
        detail:"It is stated that I want to have my FYP with you.Kindly allow me to do so!"
      },
      {
        key:5,
        title:"Fyp Enrollement",
        sender:"Ayesha Zahid",
        email:"bcsf18m520@pucit.edu.pk",
        detail:"It is stated that I want to have my FYP with you.Kindly allow me to do so!"
      },
      {
        key:6,
        title:"Final Year Project",
        sender:"Rabbia Arshad",
        email:"bcsf18m537@pucit.edu.pk",
        detail:"It is stated that I want to have my FYP with you.Kindly allow me to do so!"
      },
      {
        key:7,
        title:"Fyp Selection",
        sender:"Muddasir Iqbal",
        email:"bcsf18m502@pucit.edu.pk",
        detail:"It is stated that I want to have my FYP with you.Kindly allow me to do so!"
      }
  ];
  export default RequestsList;