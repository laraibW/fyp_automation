const ListProjects=[
    {
      key:1,
      projectId:'Bcsf18M-112',
      title:"FYP Automation System",
      leader:"Hamda Tariq",
      members:["Hamda Tariq","Laraib Waheed","Abeera Khalid","Sidra Tanveer"] ,
      emailIds:["bcsf18m525pucit.edu.pk","bcsf18m523pucit.edu.pk","bcsf18m526pucit.edu.pk","bcsf18m541pucit.edu.pk"],
      status:"In Process"
    },
  
    {
      key:2,
      projectId:'Bcsf18M-113',
      title:"Student Management System",
      leader:"Farzad",
      members:["Farzad","Sumita","Fatima"] ,
      emailIds:["bcsf18m514pucit.edu.pk","bcsf18m527pucit.edu.pk","bcsf18m506pucit.edu.pk"],
      status:"In Process"
    },

    {
        key:3,
        projectId:'Bcsf18M-114',
        title:"Meeting Record System",
        leader:"Ayesha Zahid",
        members:["Ayesha Zahid","Aqsa Afzal"] ,
        emailIds:["bcsf18m520pucit.edu.pk","bcsf18m554pucit.edu.pk"],
        status:"In Process"
    },
    {
      key:4,
      projectId:'Bcsf18M-115',
      title:"Campus Management System",
      leader:"Usman",
      members:["Usman Farooq", "Sidra Rasool"] ,
      emailIds:["bcsf18a541pucit.edu.pk","bcsf18a551pucit.edu.pk"],
      status:"In Process"
  },
  {
    key:5,
    projectId:'Bcsf18M-116',
    title:"Deaf Sign Translation",
    leader:"Mudassir Iqbal",
    members:["Mudassir Iqbal","Rabbia Arshad"] ,
    emailIds:["bcsf18m502pucit.edu.pk","bcsf18m537pucit.edu.pk"],
    status:"In Process"
},
{
  key:6,
  projectId:'Bcsf18M-117',
  title:"E-Commerce Website",
  leader:"Arooj Ali",
  members:["Arooj Ali","Iqra Parveen"] ,
  emailIds:["bcsf18m518pucit.edu.pk","bcsf18m551pucit.edu.pk"],
  status:"In Process"
},
      
  ];
  export default ListProjects;
  